livery = {
	{"ext1", 0 ,"M2KC_1T_RAF1",false};
	{"ext2", 0 ,"M2KC_2T_RAF1",false};	
	{"ext6", 0 ,"M2KC_6T_RAF1",false};
	{"ext7", 0 ,"M2KC_7T_RAF1",false};
	{"ext8", 0 ,"M2KC_8T_RAF1",false};
	{"ext11", 0 ,"M2KC_10T_RAF1",false};
	
	{"FUSE_NUMBER1_001", 0 ,"M2KC_1T_RAF1",false};
	{"FUSE_NUMBER1_001", DECAL ,"empty",true};

	{"FUSE_NUMBER2_001", 0 ,"M2KC_1T_RAF1",false};
	{"FUSE_NUMBER2_001", DECAL ,"empty",true};

	{"FUSE_NUMBER2_010", 0 ,"M2KC_1T_RAF1",false};
	{"FUSE_NUMBER2_010", DECAL ,"empty",true};

	{"TAIL_NUMBER1_001", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER1_001", DECAL ,"empty",true};

	{"TAIL_NUMBER1_010", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER1_010", DECAL ,"empty",true};

	{"TAIL_NUMBER1_100", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER1_100", DECAL ,"empty",true};

	{"TAIL_NUMBER2_001", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER2_001", DECAL ,"empty",true};

	{"TAIL_NUMBER2_010", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER2_010", DECAL ,"empty",true};

	{"TAIL_NUMBER2_100", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER2_100", DECAL ,"empty",true};

	{"TAIL_NUMBER3_001", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER3_001", DECAL ,"empty",true};

	{"TAIL_NUMBER3_010", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER3_010", DECAL ,"empty",true};

	{"TAIL_NUMBER3_100", 0 ,"M2KC_2T_RAF1",false};
	{"TAIL_NUMBER3_100", DECAL ,"empty",true};

	{"NOSE_NUMBER_001", 0 ,"M2KC_1T_RAF1",false};
	{"NOSE_NUMBER_001", DECAL ,"empty",true};

	{"NOSE_NUMBER_010", 0 ,"M2KC_1T_RAF1",false};
	{"NOSE_NUMBER_010", DECAL ,"empty",true};

	{"NOSE_NUMBER_100", 0 ,"M2KC_1T_RAF1",false};
	{"NOSE_NUMBER_100", DECAL ,"empty",true};

	{"WINGR_NUMBER_001", 0 ,"M2KC_2T_RAF1",false};
	{"WINGR_NUMBER_001", DECAL ,"empty",true};

	{"WINGR_NUMBER_010", 0 ,"M2KC_2T_RAF1",false};
	{"WINGR_NUMBER_010", DECAL ,"empty",true};

	{"WINGR_NUMBER_100", 0 ,"M2KC_2T_RAF1",false};
	{"WINGR_NUMBER_100", DECAL ,"empty",true};

	{"WINGL_NUMBER_001", 0 ,"M2KC_1T_RAF1",false};
	{"WINGL_NUMBER_001", DECAL ,"empty",true};

	{"WINGL_NUMBER_010", 0 ,"M2KC_1T_RAF1",false};
	{"WINGL_NUMBER_010", DECAL ,"empty",true};

	{"WINGL_NUMBER_100", 0 ,"M2KC_1T_RAF1",false};
	{"WINGL_NUMBER_100", DECAL ,"empty",true};
	
}
name = "Navy Grey Camo Agressor"
countries = {"CZE","USA","RUS","FRA","UKR","SPN","NETH","TUR","BEL","GER","NOR","CAN","POL","DEN","UK","GRG","ISR","ABH","RSO","ITA",}